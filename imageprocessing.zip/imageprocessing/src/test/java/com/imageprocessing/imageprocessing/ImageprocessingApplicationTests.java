package com.imageprocessing.imageprocessing;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertTrue;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.fail;

// import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// import com.imageprocessing.imageprocessing.exceptions.FilterException;
// import com.imageprocessing.imageprocessing.filters.GrayscaleFilter;
// import com.imageprocessing.imageprocessing.filters.ImageFilter;
// import com.imageprocessing.imageprocessing.utils.ImageGallery;

// import com.imageprocessing.imageprocessing.exceptions.FilterException;
// import com.imageprocessing.imageprocessing.filters.BlurFilter;
// import com.imageprocessing.imageprocessing.filters.ImageFilter;

// import com.imageprocessing.imageprocessing.exceptions.FilterException;
// import com.imageprocessing.imageprocessing.filters.GrayscaleFilter;
// import com.imageprocessing.imageprocessing.filters.ImageFilter;
// import com.imageprocessing.imageprocessing.utils.ImageGallery;

@SpringBootTest
class ImageprocessingApplicationTests {

	@Test
	void contextLoads() {
	}

//   @Test
//     public void testAddAndRemoveImage() {
//         ImageGallery gallery = new ImageGallery();
//         BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
//         gallery.addImage(img);
//         assertTrue(gallery.getImages().contains(img));
//         gallery.removeImage(img);
//         assertFalse(gallery.getImages().contains(img));
//     }

//     @Test
//     public void testApplyFilter() throws FilterException {
//         ImageGallery gallery = new ImageGallery();
//         BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
//         gallery.addImage(img);

//         ImageFilter filter = new GrayscaleFilter();
//         gallery.applyFilterToAll(filter);

//         assertNotNull(gallery.getImages().get(0));
//     }

//     @Test
//     public void testUndoFilter() throws FilterException {
//         ImageGallery gallery = new ImageGallery();
//         BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
//         gallery.addImage(img);

//         ImageFilter filter = new GrayscaleFilter();
//         gallery.applyFilterToAll(filter);
//         gallery.undoLastFilter();

//         assertEquals(img, gallery.getImages().get(0));
//     }


	//     @Test
   //  void testApplyFilter() throws FilterException {
   //      // Create a sample BufferedImage
   //      BufferedImage img = new BufferedImage(5, 5, BufferedImage.TYPE_INT_RGB);

   //      // Fill image with some color
   //      for (int x = 0; x < 5; x++) {
   //          for (int y = 0; y < 5; y++) {
   //              img.setRGB(x, y, 0xFF0000); // Red color
   //          }
   //      }

   //      // Apply the filter
   //      ImageFilter filter = new BlurFilter();
   //      BufferedImage result = filter.applyFilter(img);

   //      // Validate the result
   //      assertNotNull(result);
   //      assertEquals(img.getWidth(), result.getWidth());
   //      assertEquals(img.getHeight(), result.getHeight());
   //  }
	  
   // @Test
   // public void testGrayscaleFilter() {
   //    try {
   //          // Create a sample image with known color
   //       BufferedImage originalImage = new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB);
   //       originalImage.setRGB(0, 0, Color.RED.getRGB());
   //       originalImage.setRGB(1, 0, Color.GREEN.getRGB());
   //       originalImage.setRGB(0, 1, Color.BLUE.getRGB());
   //       originalImage.setRGB(1, 1, Color.YELLOW.getRGB());

   //          // Apply the grayscale filter
   //       GrayscaleFilter filter = new GrayscaleFilter();
   //       BufferedImage resultImage = filter.applyFilter(originalImage);

   //          // Check if all pixels are grayscale
   //       for (int y = 0; y < originalImage.getHeight(); y++) {
   //          for (int x = 0; x < originalImage.getWidth(); x++) {
   //             Color color = new Color(resultImage.getRGB(x, y));
   //             int red = color.getRed();
   //             int green = color.getGreen();
   //             int blue = color.getBlue();
   //             assertEquals(red, green, "Pixel at (" + x + "," + y + ") is not grayscale");
   //             assertEquals(green, blue, "Pixel at (" + x + "," + y + ") is not grayscale");
   //             }
   //          }
   //       } catch (FilterException e) {
   //          fail("Filter application failed with exception: " + e.getMessage());
   //    }
   // }

	// private ImageGallery gallery;
   // private BufferedImage testImage;

   // @BeforeEach
   // public void setUp() {
   //    gallery = new ImageGallery();
   //    testImage = new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB);
   //    testImage.setRGB(0, 0, Color.RED.getRGB());
   //    testImage.setRGB(1, 0, Color.GREEN.getRGB());
   //    testImage.setRGB(0, 1, Color.BLUE.getRGB());
   //    testImage.setRGB(1, 1, Color.YELLOW.getRGB());
   // }

   // @Test
   // public void testAddAndRemoveImage() {
   //    gallery.addImage(testImage);
   //    assertEquals(1, gallery.getImages().size(), "Image should be added to the gallery");

   //    gallery.removeImage(testImage);
   //    assertEquals(0, gallery.getImages().size(), "Image should be removed from the gallery");
   // }

   // @Test
   // public void testApplyFilterToAll() {
   //    gallery.addImage(testImage);
   //    ImageFilter filter = new GrayscaleFilter();

   //    try {
   //       gallery.applyFilterToAll(filter);
   //       BufferedImage filteredImage = gallery.getImages().get(0);

   //          // Check if all pixels are grayscale
   //       for (int y = 0; y < filteredImage.getHeight(); y++) {
   //          for (int x = 0; x < filteredImage.getWidth(); x++) {
   //             Color color = new Color(filteredImage.getRGB(x, y));
   //             int red = color.getRed();
   //             int green = color.getGreen();
   //             int blue = color.getBlue();
   //             assertEquals(red, green, "Pixel at (" + x + "," + y + ") is not grayscale");
   //             assertEquals(green, blue, "Pixel at (" + x + "," + y + ") is not grayscale");
   //             }
   //          }
   //    } catch (FilterException e) {
   //       fail("Filter application failed with exception: " + e.getMessage());
   //    }
   // }

   // @Test
   // public void testUndoLastFilter() {
   // gallery.addImage(testImage);
   // ImageFilter filter = new GrayscaleFilter();

   //    try {
   //       gallery.applyFilterToAll(filter);
   //       gallery.undoLastFilter();
   //       BufferedImage originalImage = gallery.getImages().get(0);

   //          // Check if the image is back to its original state
   //       assertEquals(testImage.getRGB(0, 0), originalImage.getRGB(0, 0), "Image was not restored correctly");
   //       assertEquals(testImage.getRGB(1, 0), originalImage.getRGB(1, 0), "Image was not restored correctly");
   //       assertEquals(testImage.getRGB(0, 1), originalImage.getRGB(0, 1), "Image was not restored correctly");
   //       assertEquals(testImage.getRGB(1, 1), originalImage.getRGB(1, 1), "Image was not restored correctly");
   //    } catch (FilterException e) {
   //       fail("Undo operation failed with exception: " + e.getMessage());
   //    }
   // }

}
