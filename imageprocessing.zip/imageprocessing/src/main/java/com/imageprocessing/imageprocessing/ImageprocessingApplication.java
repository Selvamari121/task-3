package com.imageprocessing.imageprocessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageprocessingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageprocessingApplication.class, args);
	}
}
